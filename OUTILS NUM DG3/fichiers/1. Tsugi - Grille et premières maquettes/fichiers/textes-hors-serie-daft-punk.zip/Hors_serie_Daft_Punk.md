# TSUGI · Daft Punk

> **Manuscrit de mise en page · 16 pages · Relecture pour lecteurs non spécialistes**
>
> Les bandeaux **P.** correspondent au chemin de fer. Les blocs **VISUEL** servent à la recherche et au placement. Les légendes et les crédits se composent séparément. Les liens de travail et les vérifications qui restent à faire sont en fin de document.

---

## P. 01 · Couverture

**TSUGI · HORS-SÉRIE**

### Daft Punk

**Comment on fabrique des robots**

Les photos, les clips et les idées derrière Daft Punk

**En couverture** · La photo que le manager voulait garder · Une nuit blanche pour quarante lumières · Pharrell croyait chanter pour un autre

> **VISUEL 01 · Couverture**  
> Concevoir une illustration originale autour d’une visière de la période *Discovery*. Chercher des références de profil ou de trois quarts pour qu’on reconnaisse la forme sans multiplier les détails. Prévoir un cadrage assez large pour pouvoir reprendre un détail en quatrième de couverture.

---

## P. 02 · Entrée dans le numéro

### Vous connaissez déjà leur tête

Thomas Bangalter porte le casque argenté. Guy-Manuel de Homem-Christo porte le doré. En 1996, un photographe de Dijon les prend encore à visage découvert, derrière des platines. Quand il sort de la cabine, leur nouveau manager lui demande de garder les photos pour lui.

La photo paraît quand même. Quelques années plus tard, les deux musiciens arrivent à une séance pour un magazine britannique avec des casques encombrants, de l’électronique et des fils dissimulés dans leurs vêtements. Entre ces deux images, ils ont enregistré des disques et fait tourner des clips. Ce numéro raconte aussi le travail de ceux qui ont fixé ces images sur pellicule, fabriqué les décors et monté les concerts.

> **MISE EN PAGE · Ouverture courte**  
> Composer ce texte en un seul bloc, avec une marge généreuse. Reprendre la couleur de couverture. Pas de portrait supplémentaire ni d’image décorative. Ce texte présente l’angle, il ne constitue pas un second sommaire.

---

## P. 03 · Sommaire

### Dans ce numéro

**04 · Avant les casques**  
À Dijon, un photographe les prend à visage découvert. Leur manager préférerait que les images restent dans l’appareil.

**06 · Il faut être à Rennes samedi**  
Avant les grandes scènes, il faut déjà réussir à arriver au concert. Les débuts du duo et de son premier album.

**08 · Quarante ronds et une nuit blanche**  
Un clip fabriqué comme une partition, puis deux costumes qui deviennent une identité.

**10 · Ce qu’une pyramide a changé**  
Une pyramide, des morceaux qui se mélangent et 250 spectateurs derrière la caméra.

**12 · Pharrell pensait qu’on le remplacerait**  
Deux séances à Paris, une voix de démonstration, puis la première écoute de « Get Lucky ».

**14 · Vingt ans pour retrouver quelques secondes**  
D’où vient la boucle de « Fresh » ? Une trouvaille faite en cherchant des sons pour un autre morceau.

---

## P. 04 · Ouverture

### Avant les casques

**Chapô** · Dijon, novembre 1996. Cyril Villemain doit rapporter une photo pour deux colonnes dans *Le Bien Public*. À L’An-Fer, Daft Punk joue vers trois heures du matin. Le photographe monte dans la cabine avec un film de 24 poses.

Il a 23 ans et couvre depuis un an les soirées techno du club. Ce soir-là, la cabine est presque noire. Avec son 24 mm, Villemain photographie les deux DJs de près. Il dirige le flash vers le plafond pour éviter de les éclairer de face. Quelques minutes lui suffisent. Il pense avoir pris une douzaine de vues, la moitié de sa pellicule.

La première s’est déclenchée alors qu’il venait à peine d’amorcer le film. Elle n’aurait normalement pas dû exister. Sur d’autres images, Guy-Manuel de Homem-Christo change de disque ; Thomas Bangalter reste près des platines. Villemain dit avoir des souvenirs assez flous de l’ordre des gestes. Il se rappelle en revanche le moment où le duo passe « Rollin’ & Scratchin’ ». La salle réagit.

L’album *Homework* ne sortira qu’en janvier 1997. Sur ces photos, on peut encore voir les deux musiciens au travail sans costume ni visière. Villemain redescend avec sa pellicule. Quelqu’un vient lui demander ce qu’il compte en faire.

> **VISUEL 04A · La photo de Dijon**  
> Chercher le tirage « Daft Punk, DJ set à L’An-Fer, Dijon 1996 » dans le portfolio de Cyril Villemain chez Cut Off Gallery. Demander le fichier et les conditions de reproduction. Garder le cadrage de la cabine si possible. La photo est la pièce principale de l’ouverture.

**Légende** · Thomas Bangalter et Guy-Manuel de Homem-Christo à L’An-Fer, à Dijon, en novembre 1996.

**Crédit** · Cyril Villemain. Reproduction à confirmer.

---

## P. 05 · Ouverture, suite

#### La photo paraît

L’homme se présente comme le nouveau manager de Daft Punk. Selon le récit de Villemain, il lui explique que le groupe ne montrera bientôt plus son visage et lui demande de ne pas publier les clichés. Le photographe répond qu’il travaille à la pige pour un quotidien régional : sans article, il ne sera pas payé. La conversation se termine autour d’un verre. Quelques jours après, la photo paraît dans *Le Bien Public*.

Ce n’est pas une photo volée des robots démasqués. Elle a été prise au travail, devant les platines, à un moment où les casques n’existent pas encore. Le photographe garde une image pour son journal ; le manager tente déjà de limiter la circulation de ces visages. Le journal publie finalement la photo.

Un an plus tôt, une autre rencontre a failli ne pas se faire. Elle n’avait besoin d’aucun appareil photo, seulement d’une voiture, de machines et d’un trajet jusqu’à Rennes.

> **VISUEL 05A · La coupure du journal, si elle est retrouvée**  
> Chercher l’article de novembre 1996 dans les archives du *Bien Public*, ou demander si le photographe en conserve un exemplaire. Garder le titre du journal ou de la rubrique visible. Si la coupure reste introuvable, composer cette page avec le récit et les cinq dates.

**Légende conditionnelle** · Le cliché pris à L’An-Fer paraît dans *Le Bien Public* quelques jours après la soirée, selon le photographe.

#### Cinq dates

1995	Daft Punk joue à l’Ubu, à Rennes, en pleine grève des transports.

1997	Le premier album, Homework, sort en janvier.

2001	Discovery paraît. Les robots sont en couverture du magazine britannique The Face.

2007	Le public filme le concert de Coney Island. Le disque de la tournée est enregistré à Bercy.

2013	Random Access Memories, le dernier album studio, sort en mai.

---

## P. 06 · Les débuts

### Il faut être à Rennes samedi

**Chapô** · Jean-Louis Brossard a découvert Daft Punk sur un disque venu d’Écosse. Il les programme aux Trans Musicales. Le vendredi précédant leur concert, il doit expliquer à la presse que les deux musiciens risquent de manquer leur concert à Rennes.

C’est décembre 1995 et les grèves compliquent les trajets. Le duo doit rejoindre l’Ubu, un club de Rennes, avec ses machines. Brossard se souvient que Thomas Bangalter vient tout juste d’avoir son permis. La production lui demande de prendre sa voiture et de charger le matériel pour rejoindre l’aéroport de Roissy. Le samedi, Daft Punk joue comme prévu. Sur la photo d’Éric Pérez, les deux musiciens sont encore à visage découvert. Pour ceux qui ont fait venir le groupe, c’est déjà une bonne nouvelle de les voir derrière leurs machines.

#### Le disque qui a donné envie de les inviter

Le disque que Brossard a entendu s’appelle « Da Funk ». Il est sorti en 1995 chez Soma, un label écossais qui avait déjà publié le premier vinyle du duo l’année précédente. Les gens de Soma se souviennent de la démo. Au bureau, ils appellent encore le morceau le lent et funky. Ils demandent aux deux Parisiens de le terminer. Plus tard, des DJs de house comme de techno leur disent qu’ils le passent en soirée. C’est comme ça que le morceau arrive chez des gens qui n’ont jamais vu jouer Daft Punk.

Sur le vinyle, il suffit de retourner le disque pour changer d’ambiance. « Da Funk » a cette basse qu’on peut retenir au bout de quelques mesures. Sur l’autre face, « Rollin’ & Scratchin’ » répète un son plus râpeux jusqu’à ce qu’il prenne toute la place. À Dijon, l’année suivante, Cyril Villemain se souvient que c’est celui-là qui fait réagir la salle. On peut suivre un bout du parcours du duo à partir de ces deux faces. L’une donne à un programmateur envie de faire venir le groupe. L’autre se fait déjà attendre sur la piste.

> **VISUEL 06A · L’Ubu, Rennes**  
> Chercher « Éric Pérez Daft Punk Ubu 2 décembre 1995 Trans Musicales ». Garder le cadre photo du premier jet. Demander le fichier et les conditions de reproduction.

**Légende** · Daft Punk à l’Ubu, pendant les Trans Musicales de Rennes, le 2 décembre 1995.

**Crédit** · Éric Pérez.

> **VISUEL 06B · Feuillet Soma, facultatif**  
> Pour le troisième cadre, chercher le feuillet « French! Teen! Techno! » reproduit dans l’entretien de Slam chez *DJ Mag*. Vérifier que le titre et la date restent lisibles.

**Légende** · Soma annonce « The New Wave », le premier disque du duo, en 1994.

**Crédit** · Document Soma Quality Recordings. Reproduction à confirmer.

---

## P. 07 · *Homework*

#### Quatre faces à remplir

À Paris, le duo enregistre chez lui. Au départ, il pense en maxis, ces vinyles qui mettent en circulation quelques titres à la fois. Quand il a assez de morceaux pour remplir les quatre faces d’un double vinyle, il les assemble. Les deux faces de « Da Funk » se retrouvent sur *Homework*, au milieu d’autres titres qui gardent la trace de ces années de club. Sur « Teachers », une voix égrène les noms de ceux que les deux musiciens écoutaient. C’est une manière de dire d’où vient le disque à des gens qui le découvrent chez eux.

Quand *Homework* paraît en janvier 1997, on peut déjà connaître « Da Funk » sans jamais avoir mis les pieds à l’Ubu. Le morceau est ressorti chez Virgin et Spike Jonze en a fait un clip. On y voit un chien à la jambe plâtrée traverser New York, avec la musique qui sort de son poste de radio. Un disque qu’un DJ pouvait glisser au milieu de son set a maintenant un personnage qu’on reconnaît à la télévision. Pour « Around the World », le duo confie l’écran à des danseurs. Cette fois, c’est la musique elle-même qui leur dit quand bouger.

> **VISUEL 07A · Pochette de Homework**  
> Chercher la pochette carrée de l’édition originale de 1997, avec le logo brodé sur fond noir. Utiliser le cadre déjà prévu.

**Légende** · Le logo brodé sur la pochette de *Homework*, paru en janvier 1997.

**Crédit** · Reproduction à confirmer d’après l’édition.

> **VISUEL 07B · Le vinyle, facultatif**  
> Pour le quatrième cadre, chercher le maxi Soma de « Da Funk » et « Rollin’ & Scratchin’ ». Prendre une vue où on peut lire le nom du label.

**Légende** · Les deux morceaux occupent les deux faces d’un même disque chez Soma en 1995.

**Crédit** · À compléter d’après le fichier retenu.

---

## P. 08 · Fabriquer les images

### Quarante ronds et une nuit blanche

**Chapô** · Pour « Around the World », Michel Gondry fait construire un plateau qui ressemble à une platine. Chaque famille de danseurs suit un instrument. Au fond, quarante cercles doivent changer de couleur sans se décaler d’une mesure.

En 1997, le clip montre des squelettes, des momies, des nageuses, des athlètes et des robots. Les robots avancent avec la voix, les squelettes suivent la guitare, les athlètes prennent les escaliers avec la basse. Gondry a dessiné le décor et travaille avec la chorégraphe Bianca Li. Avant le tournage, on teste les marches avec les danseurs. Il faut que la plateforme soit assez large pour qu’ils puissent y circuler en rejouant leurs mouvements.

Le chef opérateur Alex Lamarque se souvient surtout des lumières. Derrière chaque rond du fond, son équipe place trois lampes, chacune filtrée dans une couleur différente. Les faisceaux doivent se mélanger sans déborder sur le cercle voisin. Quarante ronds, trois lampes par rond : il en faut beaucoup. Le loueur n’a pas assez des modèles prévus. Lamarque et son équipe complètent avec d’autres projecteurs et reprennent les réglages.

Le père de Gondry écrit le programme qui commande les couleurs. Son frère Olivier soude les connexions. Lamarque raconte qu’ils ont passé presque quarante-huit heures sans dormir avant de tourner. Il va se reposer quelques heures ; il n’est même pas sûr qu’Olivier ait dormi. Quand on lance enfin la musique, les lumières du décor la suivent. L’équipe peut refaire une prise sans perdre cette synchronisation.

> **VISUEL 08A · Le plateau de Gondry**  
> Chercher « Daft Punk Around the World Michel Gondry official video ». Choisir un plan qui garde les marches, au moins deux groupes de danseurs et les ronds du fond.

**Légende** · Le plateau d’« Around the World ». Les costumes distinguent les groupes qui suivent les différentes parties du morceau.

**Crédit** · Clip réalisé par Michel Gondry, image Alex Lamarque, 1997. Reproduction à confirmer.

> **VISUEL 08B · Derrière un rond**  
> Dessiner un rond vu de face et trois lampes filtrées en rouge, vert et bleu derrière lui. Le dessin peut prendre un petit cadre. Il doit éclairer le montage décrit par Lamarque.

**Légende** · Les trois faisceaux se mélangent derrière une surface qui diffuse la lumière.

**Crédit** · Schéma original d’après le témoignage d’Alex Lamarque.

---

## P. 09 · Deux personnages à fabriquer

#### Les robots du clip ne sont pas Daft Punk

En 1997, les robots d’« Around the World » sont des danseurs en costume. Quatre ans plus tard, pour *Discovery*, Thomas Bangalter et Guy-Manuel de Homem-Christo apparaissent avec leurs propres casques. Entre les deux, ils ont parfois posé déguisés ou maquillés pour éviter les portraits à visage découvert.

À l’époque, Orla Lee-Fisher travaille au marketing de Virgin. Elle se souvient des difficultés à obtenir des photographies du groupe : chaque séance imposait une nouvelle façon de cacher les visages. Les robots mettent fin à cette improvisation. En février 2001, ils font la couverture de *The Face*, magazine britannique de musique et de mode.

La séance avec le photographe Luis Sanchis n’a rien d’un portrait devant un fond neutre. Le journaliste Piers Martin accompagne le duo à Los Angeles. L’équipe prévoit différents lieux à partir des titres de *Discovery*. Sanchis raconte une journée de déplacements rapides, avec un passage dans un magasin de guitares, puis d’autres scènes à tourner ailleurs dans la ville. Une photographie les montre au piano.

#### Le poids des casques

Sur place, Martin trouve les casques lourds. Le spécialiste des effets spéciaux Tony Gardner explique que les premières versions comportent des commandes pour l’électronique et un sac à dos pour cacher les fils. Il a travaillé à partir des dessins d’Alexandre Courtès et Martin Fougerol. Les robots que l’on voit en couverture ne sont donc pas un simple masque posé pour la photo. Leur fabrication se poursuit après cette première apparition, à mesure que le duo les utilise sur scène.

> **VISUEL 09A · The Face, février 2001**  
> Chercher « The Face Vol 3 #49 February 2001 Daft Punk Luis Sanchis ». Utiliser une reproduction où le nom du magazine et les titres de couverture restent visibles.

**Légende** · *The Face* présente les robots à l’occasion de *Discovery*, en février 2001.

**Crédit** · Luis Sanchis / *The Face*. Reproduction à confirmer.

> **VISUEL 09B · Les robots au piano, facultatif**  
> Chercher la photo de Luis Sanchis dans le reportage de Piers Martin. Elle est aussi associée au livret de *Discovery*. Garder une vue où l’action se comprend.

**Légende conditionnelle** · Le duo au piano. Pour la série, l’équipe a imaginé des scènes à partir des morceaux de *Discovery*.

**Crédit** · Luis Sanchis. Reproduction à confirmer.

---

## P. 10 · Le concert

### Ce qu’une pyramide a changé

**Chapô** · En 2005, *Human After All* reçoit des critiques pour ses répétitions. Un an plus tard, Daft Punk joue dans une pyramide éclairée à Coachella. Leur manager se souvient d’un public qui redécouvre ces mêmes morceaux sur scène.

Pedro Winter ne cherche pas à faire croire que tout le monde avait aimé le disque. Dans un entretien à *PAPER*, il raconte les réactions négatives à sa sortie, puis les messages de ceux qui ont changé d’avis après le spectacle. La tournée fait entendre les titres dans un autre ordre et dans un autre volume sonore. Elle offre aussi une image que les petites salles des débuts ne pouvaient pas produire.

À Coachella, les deux musiciens sont installés au sommet d’une grande pyramide. La construction porte les lumières et donne une forme au concert, visible depuis loin dans la foule. Thomas Bangalter dira à *PAPER* que cette date devait être l’une des deux ou trois prévues. L’accueil les conduit à prolonger la tournée.

Le disque *Alive 2007* garde la trace de ce travail d’assemblage. Sa liste de titres juxtapose « Around the World » et « Harder, Better, Faster, Stronger », puis « One More Time » et « Aerodynamic ». Une même piste peut donc faire entendre plusieurs chansons. Le concert change ce qu’on écoute en même temps que ce qu’on voit.

> **VISUEL 10A · Vue d’ensemble du clip live**  
> Chercher le clip officiel « Harder Better Faster Stronger Alive 2007 ». Retenir un photogramme où on peut situer le duo, la pyramide et le public. Noter son minutage.

**Légende** · Coney Island, New York, 2007. Un plan d’ensemble tiré du clip monté par Olivier Gondry.

**Crédit** · Image du clip live. Reproduction à confirmer.

---

## P. 11 · Le concert vu du public

#### Une caméra dans chaque rang

À Coney Island, en 2007, Daft Punk invite les spectateurs à apporter une caméra. Environ 250 personnes filment le concert. Olivier Gondry récupère leurs prises de vues pour monter une vidéo live de « Harder, Better, Faster, Stronger ». Il avait soudé les connexions lumineuses d’« Around the World » dix ans plus tôt.

La scène, cette fois, a été conçue pour être vue de loin ; les images proviennent de la foule. D’un plan à l’autre, la pyramide reste au fond, mais les têtes, la distance et l’angle changent. Gondry doit tirer un clip de toutes ces places occupées le même soir. Le résultat ne ressemble pas à une captation faite depuis une seule caméra bien installée devant la scène.

Le disque *Alive 2007* a une autre provenance. Il a été enregistré le 14 juin à Paris-Bercy. Coney Island fournit les images de la vidéo, Bercy le son du disque. La tournée a laissé ces deux documents d’un spectacle qui n’a jamais eu un seul point de vue.

> **VISUEL 11A · Une caméra parmi les spectateurs**  
> Dans le même clip, choisir un photogramme qui montre une obstruction ou un angle différent. Écrire le dernier détail de la légende après avoir vu l’image à la taille de publication.

**Légende** · Une autre place dans le public, pendant le même concert.

**Crédit** · Image du clip live monté par Olivier Gondry. Reproduction à confirmer.

> **VISUEL 11B · Bercy, l’autre document de la tournée**  
> Chercher « Nicole Blommers Daft Punk 14-6-2007 Bercy Paris ». Ce fichier de 900 × 600 px convient à un petit bloc. Séparer la photo des photogrammes de New York.

**Légende** · Paris-Bercy, le 14 juin 2007. Le clip a été filmé à New York, mais c’est ce concert parisien qui a été enregistré pour le disque *Alive 2007*.

**Crédit** · Nicole Blommers, [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/).

---

## P. 12 · Dans le studio

### Pharrell pensait qu’on le remplacerait

**Chapô** · Il arrive à Paris avec le décalage horaire, enregistre deux chansons en deux jours et repart sans pouvoir en parler. Pharrell Williams ne sait pas encore que sa voix restera sur « Get Lucky ».

Dans *GQ*, Pharrell raconte ce séjour comme une succession de moments un peu flous. Daft Punk lui fait écouter ce qu’il prépare. Les idées lui viennent, mais il est épuisé. On lui donne du Guronsan. Il enregistre un premier titre, revient le lendemain pour un second, puis reprend l’avion. Quand son équipe lui demande comment s’est passé le travail, il invoque le secret et reconnaît qu’il se souvient mal des séances.

Il croit surtout avoir enregistré une voix de démonstration. Quelqu’un d’autre pourrait venir la refaire. Dans l’épisode de *Memory Tapes* qui lui est consacré, il revient sur cette méprise. La série publie aussi des images de l’époque où il entend les morceaux terminés pour la première fois.

Sur « Get Lucky », sa voix est encore là. Nile Rodgers joue de la guitare. L’autre chanson enregistrée à Paris, « Lose Yourself to Dance », garde également sa voix. Les deux sortent sur *Random Access Memories* en 2013. Pharrell, qui pensait avoir fourni un brouillon, découvre qu’il fait partie du disque.

> **VISUEL 12A · Pharrell à l’écoute**  
> Chercher l’épisode Pharrell Williams de *Memory Tapes*. Prendre une ou deux vues de la première écoute, assez espacées pour que son expression change. Noter le minutage avant d’écrire un détail de légende supplémentaire.

**Légende** · Pharrell Williams écoute les morceaux sur lesquels il a chanté. Les images d’époque ont été publiées dans *Memory Tapes* en 2023.

**Crédit** · *Memory Tapes*, Daft Punk. Reproduction à confirmer.

---

## P. 13 · Dans le studio, suite

#### Trois micros pour raconter une vie

Giorgio Moroder a produit des disques pour Donna Summer. Daft Punk lui demande de raconter ses débuts pour *Random Access Memories*. Quand il entre en cabine, il découvre trois micros. Il demande pourquoi on lui en a préparé autant.

Dans *The Independent*, Moroder rapporte la réponse de l’équipe : l’un correspond à l’époque de sa jeunesse, le deuxième aux années 1970, le dernier au futur. Il demande qui entendra la différence. Selon son souvenir, l’ingénieur répond que personne ne l’entendra, mais que Thomas Bangalter connaîtra le micro utilisé.

Sur « Giorgio by Moroder », l’homme parle avant que le morceau ne prenne toute sa place. Il commence par raconter ses premières années dans la musique. Ce n’est qu’après ce début qu’il dit son prénom. La séance des trois micros n’est pas expliquée à l’auditeur ; Moroder l’a racontée plus tard, comme un détail du travail en studio.

> **VISUEL 13A · Giorgio Moroder, ou illustration des micros**  
> Préférer un portrait de Giorgio Moroder issu de son épisode officiel « The Collaborators », avec minutage et provenance. En alternative, dessiner trois silhouettes de micros et indiquer explicitement « Illustration de principe ». Ne pas présenter des modèles inventés comme ceux de la séance.

**Légende conditionnelle** · Giorgio Moroder revient sur sa participation à l’album dans « The Collaborators ». Si le schéma est retenu, remplacer par « Trois générations de micros pour accompagner les époques de son récit. Illustration de principe. »

**Crédit** · À adapter au portrait retenu ou à l’auteur de l’illustration.

---

## P. 14 · Remonter à la source

### Vingt ans pour retrouver quelques secondes

**Chapô** · On entend des vagues sur « Fresh », paru sur *Homework* en 1997. Sous ce bruit, un passage musical revient. Son disque d’origine n’a été retrouvé qu’en 2017.

Celui qui fait la découverte cherchait lui-même des sons à utiliser. Il tombe sur une reprise disco de « If You Leave Me Now », enregistrée par Viola Wills en 1981. La nouvelle est partagée sur Reddit, puis reprise par *Tsugi*. Des auditeurs qui cherchaient depuis longtemps la provenance de la boucle ont enfin un nom à mettre sur l’enregistrement.

On peut vérifier en écoutant les deux morceaux. Chez Viola Wills, le passage est pris dans une chanson entière. Dans « Fresh », ces quelques secondes reviennent encore et encore, avec le bruit des vagues. Le groupe a prélevé un extrait d’un disque existant : c’est ce qu’on appelle un sample. La comparaison fait entendre exactement quelle petite partie du premier enregistrement a servi au second.

> **VISUEL 14A · Le disque de Viola Wills**  
> Chercher la pochette ou l’étiquette de « If You Leave Me Now », version Viola Wills, 1981. Retenir l’édition qu’on peut identifier et une image où le titre reste lisible.

**Légende** · Viola Wills reprend « If You Leave Me Now » en 1981. Un passage de cette version est réutilisé dans « Fresh ».

**Crédit** · À confirmer d’après l’édition reproduite.

> **VISUEL 14B · À écouter côte à côte, facultatif**  
> Préparer deux renvois lisibles vers les enregistrements. Si un schéma de comparaison est réalisé, déterminer le passage exact sur les deux versions retenues avant de mettre un minutage.

---

## P. 15 · Pour écouter après les images

### Quatre façons d’entrer

Les clips et les enregistrements évoqués dans ces pages offrent quatre points de départ. Pour chacun, voici ce qu’on peut écouter ou regarder.

#### « Da Funk » · Le morceau avant les personnages

Commencer par le son, puis regarder le clip avec le chien qui traverse New York. Le morceau reste le même, mais la rue, les rencontres et les bruits lui donnent une situation. Le poste de radio porté par le personnage fait entrer la musique dans la scène.

#### « Around the World » · Suivre un seul groupe

Regarder d’abord les robots, puis les squelettes. Les déplacements attirent l’attention sur des parties différentes de la musique. Les robots suivent la voix, les squelettes la guitare.

#### « Harder, Better, Faster, Stronger » · Passer du disque à la scène

Écouter la version de *Discovery*, puis le clip live de 2007 évoqué pages 10–11. La version live associe le titre à « Around the World ». Repérer l’arrivée de chaque voix permet de suivre cet assemblage.

#### « Get Lucky » · Revenir à la première écoute

Après le morceau, regarder l’épisode consacré à Pharrell dans *Memory Tapes*. Il y revient sur sa voix de démonstration et sur la découverte des deux chansons terminées.

> **PRODUCTION · Quatre renvois à préparer**  
> Associer chaque entrée à une vidéo ou à un enregistrement officiel, avec titre lisible et QR code seulement après vérification de la destination. Pour la troisième entrée, prévoir deux liens, studio et live. Ne pas poser de faux codes dans le fichier final. Ces renvois remplacent une nouvelle série d’images décoratives.

**Crédits du numéro** · Exercice éditorial B3 Design graphique, Condé Nice, inspiré de la presse musicale. Projet pédagogique non affilié à *Tsugi*. Textes rédigés à partir des sources réunies dans le carnet de rédaction. Crédits des images à leur emplacement.

---

## P. 16 · Quatrième de couverture

**TSUGI · Hors-série Daft Punk**

**Projet pédagogique non affilié à Tsugi · B3 Design graphique · Condé Nice**

> **VISUEL 16 · Quatrième**  
> Reprendre un détail du visuel de couverture et changer son échelle. Réserver un petit bloc aux mentions d’édition et au code-barres fictif.

---

## Carnet de rédaction · Sources et suivi des visuels

| Pages | Sources et pièces à retrouver |
|---|---|
| **1–5** | [Tirage et récit de Cyril Villemain, Cut Off Gallery](https://cutoffgallery.art/collection/daft-punk-lanfer-dijon-1996) · [Tsugi nº 139, édito et sommaire](https://www.tsugi.fr/tsugi-139-aux-origines-de-daft-punk-disponible-partout/) |
| **6–7** | [Jean-Louis Brossard raconte le concert de l’Ubu](https://www.lestrans.com/article/daft-punk-has-played-at-our-house/) · [Chronologie et photo d’Éric Pérez, Les Trans](https://www.lestrans.com/article/daft-punk-1986-2021-une-chronologie/) · [Slam, les premiers maxis et le feuillet Soma, DJ Mag](https://www.djmag.fr/dossier-slam-daft-punk-avait-une-vision-qui-sortait-du-lot/) · [La fabrication de Homework, Pitchfork](https://pitchfork.com/reviews/albums/daft-punk-homework/) · [Discographie officielle, Homework](https://daftpunk.com/homework/) · [Le clip de Da Funk, Sight and Sound](https://www.bfi.org.uk/sight-and-sound/features/cinema-obscura-daft-punk-film-from-daft-eden) |
| **8–9** | [Le tournage raconté par Alex Lamarque](https://www.ucocinematographie.org/souvenirs-dun-chef-operateur-alex-lamarque-michel-gondry-daft-punk-around-the-world/) · [Storyboard et archives publiés par le duo](https://djmag.com/news/daft-punk-share-video-storyboard-around-world-watch) · [Tony Gardner, Piers Martin et les premières séances photo, DJ Mag](https://djmag.com/longreads/real-story-how-daft-punk-became-robots) · [Couverture de The Face, février 2001](https://villagebooks.co/products/the-face-vol-3-49-february-2001) |
| **10–11** | [Coney Island et les spectateurs munis de caméras, PAPER](https://www.papermag.com/daft-punk-cover) · [Clip et enregistrement de Bercy, discographie officielle](https://daftpunk.com/alive2007/) · [Photographie de Nicole Blommers à Bercy](https://commons.wikimedia.org/wiki/File:Daft_Punk,_14-6-2007,_Bercy,_Paris.jpg) |
| **12–13** | [Giorgio Moroder raconte les trois micros, The Independent](https://www.the-independent.com/arts-entertainment/art/features/daft-punk-together-in-electric-dreams-8619794.html) · [La première écoute de Pharrell, DJ Mag](https://djmag.com/news/daft-punk-share-footage-first-time-pharrell-williams-heard-get-lucky-watch) · [Pharrell revient sur l’enregistrement, GQ](https://www.gq.com/story/pharrells-random-access-memory-of-daft-punk) · [Crédits et morceaux de Random Access Memories](https://daftpunk.com/randomaccessmemories/) |
| **14–15** | [Le sample de Fresh retrouvé, Tsugi](https://www.tsugi.fr/ca-y-est-20-ans-apres-sa-sortie-on-sait-dou-provient-le-sample-de-fresh-de-daft-punk/) · Discographie et vidéos officielles mentionnées dans les sources précédentes. |

**Avant diffusion.** Confirmer les fichiers et les conditions de reproduction des archives, couvertures et photogrammes. Vérifier les légendes conditionnelles devant les images retenues. La photo de Bercy a une licence identifiée. La coupure du *Bien Public* reste une piste à retrouver. Les visuels ne sont pas encore sélectionnés ni les droits tous obtenus. Ce manuscrit peut servir à la maquette, pas encore à une diffusion publique.
